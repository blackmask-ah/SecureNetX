package application;

public class Main {
    public static void main(String[] args) {
    SplashScreen.main(args);  // Start with splash
    }
}
